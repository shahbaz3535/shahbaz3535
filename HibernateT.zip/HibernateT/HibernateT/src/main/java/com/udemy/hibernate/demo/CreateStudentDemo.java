package main.java.com.udemy.hibernate.demo;


import org.hibernate.Session; 
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import main.java.com.udemy.hibernate.demo.entity.Student;

public class CreateStudentDemo {

	public static void main(String[] args) {
		// create session factory
		SessionFactory factory = new Configuration()
									.configure("HibernateT/src/main/resources/hibernate.cfg.xml")//"hibernate.cfg.xml"
									.addAnnotatedClass(Student.class)
									.buildSessionFactory();
		//create session
		Session session = factory.getCurrentSession();
		try{			
			//create the student object
			System.out.println("creating new studrnt object");
			Student tempStudent = new Student("Paul","Wall","paul.wall@gmail.com");
			
			//start a transaction
			System.out.println("starting the transaction ");
			session.beginTransaction();
			//save the student object
			System.out.println("saving the student details");
			session.save(tempStudent);
			//commit the transaction
			session.getTransaction().commit();
			System.out.println("Done!");
		}
		finally {
			factory.close();
		}
		
	}

}