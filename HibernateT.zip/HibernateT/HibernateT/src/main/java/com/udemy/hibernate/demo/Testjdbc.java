package main.java.com.udemy.hibernate.demo;


import java.sql.Connection;
import java.sql.DriverManager;

public class Testjdbc {

	public static void main(String[] args) {
		String jdbcUrl = "jdbc:mysql://localhost:3306/hb_student_tracker?useSSL=false";
		String user= "hbstudent";
		String pass= "hbstudent";
		try {
			System.out.println("Connecting to Database: "+ jdbcUrl);
			Connection myConn=
					DriverManager.getConnection(jdbcUrl, user,pass);
			System.out.println("Connection Successful!");		
			System.out.println("3");
			System.out.println("2");
			System.out.println("1");
			System.out.println("BYE!");
			myConn.close();
			
		}
		catch(Exception exc){
			exc.printStackTrace();
		}
	}

}
